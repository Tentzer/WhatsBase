"""FastAPI application entrypoint.

Run locally: `uvicorn app.main:app --reload` (from the backend/ directory).
M1 mounts only the health router; feature routers land in later milestones.
"""

from __future__ import annotations

from fastapi import FastAPI

from app.api.health import router as health_router
from app.intake.webhook import router as webhook_router

app = FastAPI(title="WhatsApp AI Agent Builder Platform", version="0.1.0")
app.include_router(health_router)
app.include_router(webhook_router)
